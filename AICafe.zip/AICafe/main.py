"""
AI Food Waste Reduction — FastAPI Backend

Endpoints:
  GET  /                          Health check
  POST /predict                   Predict demand for a single item
  POST /batch-predict             Predict demand for multiple items
  POST /menu-optimize             Suggest menu adjustments for a center
  POST /purchase-suggest          Recommend ingredient quantities
  GET  /analytics/waste-summary   Waste reduction analytics
"""
import os
import json
import numpy as np
import pandas as pd
import joblib
from contextlib import asynccontextmanager
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
from typing import List, Optional

from training.config import SAVED_MODELS_DIR, ARTIFACTS_DIR, DATA_PATH
from training.model import EnsembleModel
from training.data_preprocessing import engineer_features, load_data


# ─── Pydantic Models ──────────────────────────────────────rf2──────────────────

class PredictRequest(BaseModel):
    week: int = Field(..., ge=1, description="Week number")
    center_id: int = Field(..., ge=1, description="Fulfilment center ID")
    meal_id: int = Field(..., ge=1, description="Meal ID")
    checkout_price: float = Field(..., gt=0, description="Checkout price")
    base_price: float = Field(..., gt=0, description="Base price")
    emailer_for_promotion: int = Field(0, ge=0, le=1, description="Email promo (0/1)")
    homepage_featured: int = Field(0, ge=0, le=1, description="Homepage featured (0/1)")


class PredictResponse(BaseModel):
    predicted_orders: float
    confidence_low: float
    confidence_high: float
    waste_risk: str
    recommendations: List[str]


class BatchPredictRequest(BaseModel):
    items: List[PredictRequest]


class BatchPredictResponse(BaseModel):
    predictions: List[PredictResponse]
    total_predicted_orders: float


class MenuOptimizeRequest(BaseModel):
    center_id: int = Field(..., ge=1)
    week: int = Field(..., ge=1)
    target_waste_reduction_pct: float = Field(20.0, ge=0, le=100)


class MenuOptimizeResponse(BaseModel):
    center_id: int
    week: int
    recommendations: List[dict]
    estimated_waste_reduction_pct: float
    estimated_cost_savings: float


class PurchaseSuggestRequest(BaseModel):
    center_id: int = Field(..., ge=1)
    week: int = Field(..., ge=1)
    safety_margin_pct: float = Field(10.0, ge=0, le=50,
                                      description="Extra % to order as buffer")


class PurchaseSuggestResponse(BaseModel):
    center_id: int
    week: int
    meal_suggestions: List[dict]
    total_estimated_orders: float
    safety_margin_pct: float


class WasteSummaryResponse(BaseModel):
    total_records: int
    avg_orders_per_item: float
    centers_analyzed: int
    meals_analyzed: int
    top_demand_meals: List[dict]
    low_demand_meals: List[dict]
    promotion_impact: dict
    insights: List[str]


# ─── Global State ─────────────────────────────────────────────────────────────

app_state = {
    "model": None,
    "scaler": None,
    "feature_columns": None,
    "data": None,
    "training_results": None,
}


# ─── Lifespan ─────────────────────────────────────────────────────────────────

@asynccontextmanager
async def lifespan(app: FastAPI):
    """Load model and artifacts on startup."""
    print("[Startup] Loading model and artifacts...")
    try:
        app_state["model"] = EnsembleModel.load()
        app_state["scaler"] = joblib.load(
            os.path.join(ARTIFACTS_DIR, "scaler.joblib")
        )
        app_state["feature_columns"] = joblib.load(
            os.path.join(ARTIFACTS_DIR, "feature_columns.joblib")
        )

        # Load training data for analytics and feature engineering context
        df = load_data(DATA_PATH)
        # Store as raw data to avoid column conflicts during inference
        app_state["data"] = df

        results_path = os.path.join(SAVED_MODELS_DIR, "training_results.json")
        if os.path.exists(results_path):
            with open(results_path) as f:
                app_state["training_results"] = json.load(f)

        print("[Startup] All artifacts loaded successfully!")
    except Exception as e:
        print(f"[Startup] WARNING: Could not load model — {e}")
        print("[Startup] API will run but predictions will fail until model is trained.")
    yield
    print("[Shutdown] Cleaning up...")


# ─── App ──────────────────────────────────────────────────────────────────────

app = FastAPI(
    title="AI Food Waste Reduction API",
    description=(
        "Predict food demand, optimize menus, and reduce waste in "
        "restaurants & cafeterias using a stacking ensemble of "
        "XGBoost + LightGBM + CatBoost with a Ridge meta-learner."
    ),
    version="2.0.0",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# ─── Helpers ──────────────────────────────────────────────────────────────────

def _check_model():
    if app_state["model"] is None:
        raise HTTPException(
            status_code=503,
            detail="Model not loaded. Run `python -m training.train` first.",
        )


def _build_feature_row(req: PredictRequest) -> pd.DataFrame:
    """Build a single-row DataFrame and run feature engineering."""
    row = {
        "id": 0,
        "week": req.week,
        "center_id": req.center_id,
        "meal_id": req.meal_id,
        "checkout_price": req.checkout_price,
        "base_price": req.base_price,
        "emailer_for_promotion": req.emailer_for_promotion,
        "homepage_featured": req.homepage_featured,
        "num_orders": 0,  # placeholder
    }

    # Get historical data for this center-meal pair for proper feature engineering
    # Only select raw columns to avoid conflict with engineering logic
    hist_df = app_state["data"]
    columns_to_keep = [
        "id", "week", "center_id", "meal_id", "checkout_price", "base_price",
        "emailer_for_promotion", "homepage_featured", "num_orders"
    ]
    # Filter only available columns from hist_df
    hist_raw = hist_df[
        (hist_df["center_id"] == req.center_id) & (hist_df["meal_id"] == req.meal_id)
    ][columns_to_keep].copy()

    # Append the new row to relevant history
    new_row_df = pd.DataFrame([row])
    combined = pd.concat([hist_raw, new_row_df], ignore_index=True)
    combined = engineer_features(combined, is_training=False)

    # Take the last row (our prediction row)
    feature_row = combined.iloc[[-1]]
    return feature_row


def _predict_single(req: PredictRequest) -> PredictResponse:
    """Make a prediction for a single item."""
    feature_row = _build_feature_row(req)
    feature_cols = app_state["feature_columns"]
    scaler = app_state["scaler"]
    model = app_state["model"]

    # Ensure all feature columns exist
    for col in feature_cols:
        if col not in feature_row.columns:
            feature_row[col] = 0

    X = feature_row[feature_cols].values
    X_scaled = scaler.transform(X)
    prediction = float(model.predict(X_scaled)[0])
    prediction = max(prediction, 0)

    # Confidence interval (heuristic: ±20% or minimum ±5 orders)
    margin = max(prediction * 0.20, 5)
    low = max(prediction - margin, 0)
    high = prediction + margin

    # Waste risk assessment
    if prediction < 20:
        waste_risk = "LOW"
    elif prediction < 60:
        waste_risk = "MEDIUM"
    else:
        waste_risk = "HIGH"

    # Recommendations
    recommendations = []
    discount_pct = (req.base_price - req.checkout_price) / req.base_price * 100

    if waste_risk == "HIGH":
        recommendations.append(
            f"High demand expected (~{prediction:.0f} orders). "
            "Ensure sufficient ingredient stock."
        )
    elif waste_risk == "LOW":
        recommendations.append(
            f"Low demand expected (~{prediction:.0f} orders). "
            "Consider reducing preparation quantities."
        )

    if discount_pct > 30:
        recommendations.append(
            f"Large discount ({discount_pct:.0f}%) applied — "
            "monitor profit margins."
        )

    if req.emailer_for_promotion and req.homepage_featured:
        recommendations.append(
            "Dual promotion active — expect demand spike."
        )
    elif not req.emailer_for_promotion and not req.homepage_featured:
        recommendations.append(
            "No promotions active. Consider a promo to boost demand for this item."
        )

    return PredictResponse(
        predicted_orders=round(prediction, 1),
        confidence_low=round(low, 1),
        confidence_high=round(high, 1),
        waste_risk=waste_risk,
        recommendations=recommendations,
    )


# ─── Endpoints ────────────────────────────────────────────────────────────────

@app.get("/")
async def root():
    """Health check and API info."""
    model_loaded = app_state["model"] is not None
    return {
        "service": "AI Food Waste Reduction API",
        "status": "healthy",
        "model_loaded": model_loaded,
        "version": "1.0.0",
        "endpoints": [
            "POST /predict",
            "POST /batch-predict",
            "POST /menu-optimize",
            "POST /purchase-suggest",
            "GET  /analytics/waste-summary",
        ],
    }


@app.post("/predict", response_model=PredictResponse)
async def predict(req: PredictRequest):
    """Predict demand for a single meal item."""
    _check_model()
    return _predict_single(req)


@app.post("/batch-predict", response_model=BatchPredictResponse)
async def batch_predict(req: BatchPredictRequest):
    """Predict demand for multiple items at once."""
    _check_model()
    predictions = [_predict_single(item) for item in req.items]
    total = sum(p.predicted_orders for p in predictions)
    return BatchPredictResponse(
        predictions=predictions,
        total_predicted_orders=round(total, 1),
    )


@app.post("/menu-optimize", response_model=MenuOptimizeResponse)
async def menu_optimize(req: MenuOptimizeRequest):
    """Suggest menu adjustments to minimize waste for a given center and week."""
    _check_model()
    df = app_state["data"]

    # Get all meals available at this center
    center_data = df[df["center_id"] == req.center_id]
    if center_data.empty:
        raise HTTPException(404, f"No data for center_id={req.center_id}")

    meal_ids = center_data["meal_id"].unique()
    recommendations = []

    for meal_id in meal_ids:
        meal_data = center_data[center_data["meal_id"] == meal_id]
        avg_orders = meal_data["num_orders"].mean()
        avg_price = meal_data["checkout_price"].mean()
        base_price = meal_data["base_price"].mean()

        # Predict current demand
        pred_req = PredictRequest(
            week=req.week,
            center_id=req.center_id,
            meal_id=int(meal_id),
            checkout_price=round(avg_price, 2),
            base_price=round(base_price, 2),
            emailer_for_promotion=0,
            homepage_featured=0,
        )
        pred = _predict_single(pred_req)

        # Determine action
        action = "MAINTAIN"
        suggested_price = avg_price
        reason = ""

        if pred.predicted_orders < 15:
            action = "CONSIDER_REMOVING"
            reason = "Very low predicted demand — may lead to waste."
        elif pred.predicted_orders < 30:
            action = "REDUCE_QUANTITY"
            suggested_price = round(avg_price * 0.85, 2)
            reason = "Low demand — discount slightly and reduce prep quantity."
        elif pred.predicted_orders > 100:
            action = "INCREASE_QUANTITY"
            reason = "High demand expected — ensure ample stock."
        else:
            reason = "Demand is within acceptable range."

        recommendations.append({
            "meal_id": int(meal_id),
            "predicted_orders": round(pred.predicted_orders, 1),
            "current_avg_price": round(avg_price, 2),
            "suggested_price": round(suggested_price, 2),
            "action": action,
            "reason": reason,
        })

    # Sort by predicted_orders
    recommendations.sort(key=lambda x: x["predicted_orders"])

    remove_count = sum(1 for r in recommendations if r["action"] == "CONSIDER_REMOVING")
    estimated_waste_reduction = min(
        req.target_waste_reduction_pct,
        remove_count / max(len(recommendations), 1) * 100 * 2,
    )
    estimated_savings = estimated_waste_reduction * 50  # rough $/week

    return MenuOptimizeResponse(
        center_id=req.center_id,
        week=req.week,
        recommendations=recommendations,
        estimated_waste_reduction_pct=round(estimated_waste_reduction, 1),
        estimated_cost_savings=round(estimated_savings, 2),
    )


@app.post("/purchase-suggest", response_model=PurchaseSuggestResponse)
async def purchase_suggest(req: PurchaseSuggestRequest):
    """Recommend ingredient quantities based on predicted demand."""
    _check_model()
    df = app_state["data"]

    center_data = df[df["center_id"] == req.center_id]
    if center_data.empty:
        raise HTTPException(404, f"No data for center_id={req.center_id}")

    meal_ids = center_data["meal_id"].unique()
    suggestions = []
    total_orders = 0

    for meal_id in meal_ids:
        meal_data = center_data[center_data["meal_id"] == meal_id]
        avg_price = meal_data["checkout_price"].mean()
        base_price = meal_data["base_price"].mean()

        pred_req = PredictRequest(
            week=req.week,
            center_id=req.center_id,
            meal_id=int(meal_id),
            checkout_price=round(avg_price, 2),
            base_price=round(base_price, 2),
            emailer_for_promotion=0,
            homepage_featured=0,
        )
        pred = _predict_single(pred_req)
        predicted = pred.predicted_orders
        total_orders += predicted

        # Apply safety margin
        purchase_qty = predicted * (1 + req.safety_margin_pct / 100)

        suggestions.append({
            "meal_id": int(meal_id),
            "predicted_demand": round(predicted, 1),
            "recommended_purchase_qty": round(purchase_qty, 0),
            "safety_margin_units": round(purchase_qty - predicted, 1),
            "waste_risk": pred.waste_risk,
        })

    suggestions.sort(key=lambda x: x["predicted_demand"], reverse=True)

    return PurchaseSuggestResponse(
        center_id=req.center_id,
        week=req.week,
        meal_suggestions=suggestions,
        total_estimated_orders=round(total_orders, 1),
        safety_margin_pct=req.safety_margin_pct,
    )


@app.get("/analytics/waste-summary", response_model=WasteSummaryResponse)
async def waste_summary():
    """Provide waste reduction analytics and insights."""
    df = app_state.get("data")
    if df is None:
        raise HTTPException(503, "Data not loaded yet.")
    
    # Engineer on-the-fly for analytics insights
    df = engineer_features(df, is_training=False)

    total = len(df)
    avg_orders = float(df["num_orders"].mean())
    n_centers = int(df["center_id"].nunique())
    n_meals = int(df["meal_id"].nunique())

    # Top and bottom demand meals
    meal_demand = df.groupby("meal_id")["num_orders"].mean().sort_values(ascending=False)
    top_meals = [
        {"meal_id": int(mid), "avg_orders": round(float(avg), 1)}
        for mid, avg in meal_demand.head(5).items()
    ]
    low_meals = [
        {"meal_id": int(mid), "avg_orders": round(float(avg), 1)}
        for mid, avg in meal_demand.tail(5).items()
    ]

    # Promotion impact
    promo_orders = float(df[df["any_promo"] == 1]["num_orders"].mean()) if "any_promo" in df.columns else avg_orders
    no_promo_orders = float(df[df["any_promo"] == 0]["num_orders"].mean()) if "any_promo" in df.columns else avg_orders
    promo_impact = {
        "with_promotion_avg_orders": round(promo_orders, 1),
        "without_promotion_avg_orders": round(no_promo_orders, 1),
        "promotion_uplift_pct": round(
            (promo_orders - no_promo_orders) / max(no_promo_orders, 1) * 100, 1
        ),
    }

    # Insights
    insights = [
        f"Analyzed {total:,} historical records across {n_centers} centers and {n_meals} meals.",
        f"Average demand per item: {avg_orders:.1f} orders.",
    ]

    if promo_impact["promotion_uplift_pct"] > 10:
        insights.append(
            f"Promotions boost demand by ~{promo_impact['promotion_uplift_pct']:.0f}% — "
            "consider targeted promos for low-demand items."
        )

    low_demand_meals = meal_demand[meal_demand < 20]
    if len(low_demand_meals) > 0:
        insights.append(
            f"{len(low_demand_meals)} meals have avg demand < 20 orders — "
            "candidates for menu rotation or removal to reduce waste."
        )

    high_demand_meals = meal_demand[meal_demand > 100]
    if len(high_demand_meals) > 0:
        insights.append(
            f"{len(high_demand_meals)} meals are high-demand (>100 orders avg) — "
            "ensure reliable supply chains for these items."
        )

    # Model info
    results = app_state.get("training_results")
    if results:
        r2 = results.get("ensemble", {}).get("test", {}).get("r2", "N/A")
        insights.append(f"Model accuracy: R²={r2} on test set.")

    return WasteSummaryResponse(
        total_records=total,
        avg_orders_per_item=round(avg_orders, 1),
        centers_analyzed=n_centers,
        meals_analyzed=n_meals,
        top_demand_meals=top_meals,
        low_demand_meals=low_meals,
        promotion_impact=promo_impact,
        insights=insights,
    )
