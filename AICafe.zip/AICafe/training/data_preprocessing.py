"""
Data preprocessing and feature engineering for food demand prediction.

Features:
  - Price-based: discount, discount_pct, price_ratio, price_category
  - Promotion: promo_combo, any_promo, both_promos
  - Aggregation: center/meal/center-meal stats
  - Temporal: week_sin, week_cos, lags, rolling mean/std, EWM, momentum
  - Interactions: discount x promo, price_ratio x demand
  - Target encoding: center_id, meal_id (with K-fold to avoid leakage)
  - Outlier handling: Winsorization on target variable
"""
import os
import pandas as pd
import numpy as np
import joblib
from sklearn.model_selection import KFold
from sklearn.preprocessing import RobustScaler

from training.config import (
    DATA_PATH, ARTIFACTS_DIR, RANDOM_SEED,
    TRAIN_RATIO, VAL_RATIO, TEST_RATIO,
    TARGET_COL, ID_COL, RAW_FEATURES,
    WINSORIZE_LOWER, WINSORIZE_UPPER,
    TARGET_ENCODE_COLS, TARGET_ENCODE_SMOOTHING,
    CV_FOLDS,
)


def load_data(path: str = DATA_PATH) -> pd.DataFrame:
    """Load the raw CSV data."""
    df = pd.read_csv(path)
    print(f"[Data] Loaded {len(df):,} rows, {len(df.columns)} columns")
    return df


def winsorize_target(df: pd.DataFrame, col: str = TARGET_COL) -> pd.DataFrame:
    """Clip extreme values in the target to reduce outlier influence."""
    df = df.copy()
    lower = df[col].quantile(WINSORIZE_LOWER)
    upper = df[col].quantile(WINSORIZE_UPPER)
    clipped = df[col].clip(lower, upper)
    n_clipped = (df[col] != clipped).sum()
    df[col] = clipped
    print(f"[Data] Winsorized {n_clipped:,} target values to [{lower:.0f}, {upper:.0f}]")
    return df


def target_encode_kfold(df: pd.DataFrame, col: str, target: str,
                         n_splits: int = CV_FOLDS,
                         smoothing: int = TARGET_ENCODE_SMOOTHING,
                         is_training: bool = True) -> pd.Series:
    """
    Target encode a column using K-Fold to prevent data leakage.
    Uses smoothing: encoded = (count * mean_cat + smoothing * global_mean) / (count + smoothing)
    """
    global_mean = df[target].mean()
    encoded = pd.Series(np.nan, index=df.index, dtype=float)

    # If dataset is too small for K-Fold or we are not in training mode,
    # use simple smoothed mean encoding.
    if not is_training or len(df) < n_splits:
        stats = df.groupby(col)[target].agg(["mean", "count"])
        smoothed = (stats["count"] * stats["mean"] + smoothing * global_mean) / (
            stats["count"] + smoothing
        )
        return df[col].map(smoothed).fillna(global_mean)

    kf = KFold(n_splits=n_splits, shuffle=True, random_state=RANDOM_SEED)
    for train_idx, val_idx in kf.split(df):
        train_data = df.iloc[train_idx]
        stats = train_data.groupby(col)[target].agg(["mean", "count"])
        smoothed = (stats["count"] * stats["mean"] + smoothing * global_mean) / (
            stats["count"] + smoothing
        )
        encoded.iloc[val_idx] = df.iloc[val_idx][col].map(smoothed)

    # Fill any remaining NaNs with global mean
    encoded = encoded.fillna(global_mean)
    return encoded


def engineer_features(df: pd.DataFrame, is_training: bool = True) -> pd.DataFrame:
    """
    Create domain-specific features for food demand prediction.
    """
    df = df.copy()


    # ── Price-based features ──────────────────────────────────────────────
    df["discount"] = df["base_price"] - df["checkout_price"]
    df["discount_pct"] = df["discount"] / df["base_price"].replace(0, 1)
    df["price_ratio"] = df["checkout_price"] / df["base_price"].replace(0, 1)
    df["log_checkout_price"] = np.log1p(df["checkout_price"])
    df["log_base_price"] = np.log1p(df["base_price"])

    # Price bins
    df["price_category"] = pd.qcut(
        df["checkout_price"], q=5, labels=False, duplicates="drop"
    )

    # ── Promotion features ────────────────────────────────────────────────
    df["promo_combo"] = (
        df["emailer_for_promotion"].astype(int)
        + df["homepage_featured"].astype(int)
    )
    df["any_promo"] = (df["promo_combo"] > 0).astype(int)
    df["both_promos"] = (df["promo_combo"] == 2).astype(int)

    # ── Center-level aggregation features ─────────────────────────────────
    center_stats = df.groupby("center_id")["checkout_price"].agg(
        center_avg_price="mean",
        center_price_std="std",
        center_price_min="min",
        center_price_max="max",
    ).reset_index()
    df = df.merge(center_stats, on="center_id", how="left")

    # Center order volume
    center_order_stats = df.groupby("center_id")[TARGET_COL].agg(
        center_avg_orders="mean",
        center_order_std="std",
    ).reset_index()
    df = df.merge(center_order_stats, on="center_id", how="left")

    # ── Meal-level aggregation features ───────────────────────────────────
    meal_stats = df.groupby("meal_id")["checkout_price"].agg(
        meal_avg_price="mean",
        meal_price_std="std",
    ).reset_index()
    df = df.merge(meal_stats, on="meal_id", how="left")

    # Meal order volume
    meal_order_stats = df.groupby("meal_id")[TARGET_COL].agg(
        meal_avg_orders="mean",
        meal_order_std="std",
    ).reset_index()
    df = df.merge(meal_order_stats, on="meal_id", how="left")

    # ── Center-Meal interaction ───────────────────────────────────────────
    center_meal_stats = df.groupby(["center_id", "meal_id"])[TARGET_COL].agg(
        center_meal_avg_orders="mean",
        center_meal_order_std="std",
        center_meal_count="count",
    ).reset_index()
    df = df.merge(center_meal_stats, on=["center_id", "meal_id"], how="left")

    # ── Target encoding (K-Fold safe) ─────────────────────────────────────
    for col in TARGET_ENCODE_COLS:
        df[f"{col}_te"] = target_encode_kfold(df, col, TARGET_COL, is_training=is_training)

    # ── Week-based / temporal features ────────────────────────────────────
    df["week_sin"] = np.sin(2 * np.pi * df["week"] / 52)
    df["week_cos"] = np.cos(2 * np.pi * df["week"] / 52)
    df["week_of_quarter"] = df["week"] % 13
    df["quarter"] = (df["week"] - 1) // 13

    # Lag features (per center-meal pair, sorted by week)
    df = df.sort_values(["center_id", "meal_id", "week"])
    for lag in [1, 2, 3, 4, 8]:
        df[f"orders_lag_{lag}"] = (
            df.groupby(["center_id", "meal_id"])[TARGET_COL]
            .shift(lag)
        )

    # Rolling means
    for window in [3, 5, 8]:
        df[f"orders_rolling_mean_{window}"] = (
            df.groupby(["center_id", "meal_id"])[TARGET_COL]
            .transform(lambda x: x.shift(1).rolling(window, min_periods=1).mean())
        )

    # Rolling std (demand volatility)
    for window in [3, 5]:
        df[f"orders_rolling_std_{window}"] = (
            df.groupby(["center_id", "meal_id"])[TARGET_COL]
            .transform(lambda x: x.shift(1).rolling(window, min_periods=1).std())
        )

    # Exponentially weighted moving average
    df["orders_ewm_5"] = (
        df.groupby(["center_id", "meal_id"])[TARGET_COL]
        .transform(lambda x: x.shift(1).ewm(span=5, min_periods=1).mean())
    )

    # Momentum (week-over-week change)
    df["orders_momentum"] = (
        df.groupby(["center_id", "meal_id"])[TARGET_COL]
        .transform(lambda x: x.shift(1) - x.shift(2))
    )

    # ── Price relative to averages ────────────────────────────────────────
    df["price_vs_center_avg"] = df["checkout_price"] - df["center_avg_price"]
    df["price_vs_meal_avg"] = df["checkout_price"] - df["meal_avg_price"]
    df["price_center_ratio"] = df["checkout_price"] / df["center_avg_price"].replace(0, 1)
    df["price_meal_ratio"] = df["checkout_price"] / df["meal_avg_price"].replace(0, 1)

    # ── Interaction features ──────────────────────────────────────────────
    df["discount_x_promo"] = df["discount_pct"] * df["any_promo"]
    df["price_ratio_x_demand"] = df["price_ratio"] * df["center_meal_avg_orders"]
    df["promo_x_meal_demand"] = df["any_promo"] * df["meal_avg_orders"]
    df["discount_x_center_demand"] = df["discount_pct"] * df["center_avg_orders"]

    # ── Fill NaNs from lag/rolling with median ────────────────────────────
    for col in df.columns:
        if df[col].isna().sum() > 0:
            df[col] = df[col].fillna(df[col].median())

    return df


def get_feature_columns(df: pd.DataFrame) -> list:
    """Return the list of feature columns (everything except id and target)."""
    exclude = {ID_COL, TARGET_COL}
    return [c for c in df.columns if c not in exclude]


def split_data(df: pd.DataFrame):
    """
    Split data into train, validation, and test sets.
    Uses week-based splitting to respect temporal ordering.
    """
    max_week = df["week"].max()

    train_cutoff = int(max_week * TRAIN_RATIO)
    val_cutoff = int(max_week * (TRAIN_RATIO + VAL_RATIO))

    train_df = df[df["week"] <= train_cutoff].copy()
    val_df = df[(df["week"] > train_cutoff) & (df["week"] <= val_cutoff)].copy()
    test_df = df[df["week"] > val_cutoff].copy()

    print(f"[Data] Train: {len(train_df):,} | Val: {len(val_df):,} | Test: {len(test_df):,}")
    return train_df, val_df, test_df


def prepare_datasets(df: pd.DataFrame, feature_cols: list):
    """
    Prepare X, y arrays and fit/save the RobustScaler.
    Returns scaled X_train, X_val, X_test, y_train, y_val, y_test, and scaler.
    """
    train_df, val_df, test_df = split_data(df)

    X_train = train_df[feature_cols].values
    y_train = train_df[TARGET_COL].values
    X_val = val_df[feature_cols].values
    y_val = val_df[TARGET_COL].values
    X_test = test_df[feature_cols].values
    y_test = test_df[TARGET_COL].values

    # Fit RobustScaler on training data (handles outliers better than StandardScaler)
    scaler = RobustScaler()
    X_train = scaler.fit_transform(X_train)
    X_val = scaler.transform(X_val)
    X_test = scaler.transform(X_test)

    # Save scaler and feature columns
    joblib.dump(scaler, os.path.join(ARTIFACTS_DIR, "scaler.joblib"))
    joblib.dump(feature_cols, os.path.join(ARTIFACTS_DIR, "feature_columns.joblib"))

    print(f"[Data] Features: {len(feature_cols)} | RobustScaler saved to artifacts/")

    return X_train, X_val, X_test, y_train, y_val, y_test, scaler


def preprocess_pipeline():
    """Full preprocessing pipeline -- load, winsorize, engineer, split, scale."""
    df = load_data()
    df = winsorize_target(df)
    df = engineer_features(df, is_training=True)
    feature_cols = get_feature_columns(df)
    X_train, X_val, X_test, y_train, y_val, y_test, scaler = prepare_datasets(
        df, feature_cols
    )

    # Save the engineered dataframe for reference
    df.to_csv(os.path.join(ARTIFACTS_DIR, "engineered_data.csv"), index=False)

    return X_train, X_val, X_test, y_train, y_val, y_test, feature_cols, scaler


if __name__ == "__main__":
    preprocess_pipeline()
