"""
End-to-end training script for food demand prediction.

Uses Optuna for hyperparameter optimization, trains XGBoost + LightGBM +
CatBoost, and combines them with a stacking ensemble (Ridge meta-learner).

Usage:
    python -m training.train
"""
import sys
import time
import json
import os
import warnings

import numpy as np
import optuna
from tqdm import tqdm
from sklearn.model_selection import cross_val_score, KFold
from sklearn.linear_model import Ridge
from sklearn.metrics import (
    mean_squared_error,
    mean_absolute_error,
    r2_score,
    mean_absolute_percentage_error,
)

from training.config import (
    SAVED_MODELS_DIR, ARTIFACTS_DIR,
    RANDOM_SEED, CV_FOLDS,
    OPTUNA_N_TRIALS, OPTUNA_TIMEOUT,
    EARLY_STOPPING_ROUNDS,
)
from training.data_preprocessing import preprocess_pipeline
from training.model import (
    build_xgboost, build_lightgbm, build_catboost,
    EnsembleModel, save_individual_model,
    generate_oof_predictions,
)

# Suppress noisy warnings
warnings.filterwarnings("ignore", category=UserWarning)
optuna.logging.set_verbosity(optuna.logging.WARNING)

# Force UTF-8 output on Windows
if sys.platform == "win32":
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")


# ─── Helpers ──────────────────────────────────────────────────────────────────

def compute_metrics(y_true, y_pred, label=""):
    """Compute and print regression metrics."""
    rmse = np.sqrt(mean_squared_error(y_true, y_pred))
    mae = mean_absolute_error(y_true, y_pred)
    r2 = r2_score(y_true, y_pred)
    mape = mean_absolute_percentage_error(y_true, y_pred) * 100

    metrics = {"rmse": round(rmse, 4), "mae": round(mae, 4),
               "r2": round(r2, 4), "mape": round(mape, 2)}
    if label:
        print(f"\n  [{label}] RMSE={rmse:.4f}  MAE={mae:.4f}  R2={r2:.4f}  MAPE={mape:.2f}%")
    return metrics


class OptunaProgressBar:
    """tqdm-based callback for Optuna that shows trial progress."""
    def __init__(self, n_trials, desc="Optuna"):
        self.pbar = tqdm(total=n_trials, desc=desc, unit="trial",
                         bar_format="{l_bar}{bar:30}{r_bar}")
        self.best_value = float("inf")

    def __call__(self, study, trial):
        self.pbar.update(1)
        if study.best_value < self.best_value:
            self.best_value = study.best_value
            self.pbar.set_postfix({"best_rmse": f"{self.best_value:.4f}"})

    def close(self):
        self.pbar.close()


# ─── Optuna Objective Functions ───────────────────────────────────────────────

def xgboost_objective(trial, X_train, y_train):
    """Optuna objective for XGBoost hyperparameter optimization."""
    params = {
        "n_estimators": trial.suggest_int("n_estimators", 300, 1200),
        "max_depth": trial.suggest_int("max_depth", 3, 10),
        "learning_rate": trial.suggest_float("learning_rate", 0.005, 0.2, log=True),
        "subsample": trial.suggest_float("subsample", 0.6, 0.95),
        "colsample_bytree": trial.suggest_float("colsample_bytree", 0.6, 0.95),
        "min_child_weight": trial.suggest_int("min_child_weight", 1, 10),
        "reg_alpha": trial.suggest_float("reg_alpha", 1e-3, 10.0, log=True),
        "reg_lambda": trial.suggest_float("reg_lambda", 1e-3, 10.0, log=True),
        "gamma": trial.suggest_float("gamma", 0, 5.0),
    }
    model = build_xgboost(**params)
    scores = cross_val_score(
        model, X_train, y_train,
        cv=CV_FOLDS, scoring="neg_root_mean_squared_error", n_jobs=-1,
    )
    return -scores.mean()


def lightgbm_objective(trial, X_train, y_train):
    """Optuna objective for LightGBM hyperparameter optimization."""
    params = {
        "n_estimators": trial.suggest_int("n_estimators", 300, 1200),
        "max_depth": trial.suggest_int("max_depth", 3, 12),
        "learning_rate": trial.suggest_float("learning_rate", 0.005, 0.2, log=True),
        "subsample": trial.suggest_float("subsample", 0.6, 0.95),
        "colsample_bytree": trial.suggest_float("colsample_bytree", 0.6, 0.95),
        "min_child_samples": trial.suggest_int("min_child_samples", 3, 30),
        "reg_alpha": trial.suggest_float("reg_alpha", 1e-3, 10.0, log=True),
        "reg_lambda": trial.suggest_float("reg_lambda", 1e-3, 10.0, log=True),
        "num_leaves": trial.suggest_int("num_leaves", 20, 150),
    }
    model = build_lightgbm(**params)
    scores = cross_val_score(
        model, X_train, y_train,
        cv=CV_FOLDS, scoring="neg_root_mean_squared_error", n_jobs=-1,
    )
    return -scores.mean()


def catboost_objective(trial, X_train, y_train):
    """Optuna objective for CatBoost hyperparameter optimization."""
    params = {
        "iterations": trial.suggest_int("iterations", 300, 1200),
        "depth": trial.suggest_int("depth", 3, 10),
        "learning_rate": trial.suggest_float("learning_rate", 0.005, 0.2, log=True),
        "l2_leaf_reg": trial.suggest_float("l2_leaf_reg", 0.1, 10.0, log=True),
        "subsample": trial.suggest_float("subsample", 0.6, 0.95),
        "bagging_temperature": trial.suggest_float("bagging_temperature", 0, 5.0),
        "random_strength": trial.suggest_float("random_strength", 0.1, 10.0, log=True),
        "border_count": trial.suggest_int("border_count", 32, 255),
    }
    model = build_catboost(**params)
    scores = cross_val_score(
        model, X_train, y_train,
        cv=CV_FOLDS, scoring="neg_root_mean_squared_error", n_jobs=1,
    )
    return -scores.mean()


# ─── Model Tuning ─────────────────────────────────────────────────────────────

def tune_with_optuna(objective_fn, X_train, y_train, model_name="Model"):
    """Run Optuna study and return the best hyperparameters."""
    n_trials = OPTUNA_N_TRIALS
    print(f"\n{'='*60}")
    print(f"  Tuning {model_name} ({n_trials} Optuna trials, {CV_FOLDS}-fold CV)")
    print(f"{'='*60}")

    study = optuna.create_study(
        direction="minimize",
        sampler=optuna.samplers.TPESampler(seed=RANDOM_SEED),
    )

    progress_cb = OptunaProgressBar(n_trials, desc=f"  >> {model_name}")
    study.optimize(
        lambda trial: objective_fn(trial, X_train, y_train),
        n_trials=n_trials,
        timeout=OPTUNA_TIMEOUT,
        callbacks=[progress_cb],
    )
    progress_cb.close()

    print(f"\n  [OK] Best {model_name} RMSE: {study.best_value:.4f}")
    print(f"  [OK] Best params: {study.best_params}")

    return study.best_params


def train_stacking_meta_learner(models, X_train, y_train, X_val, y_val):
    """
    Train a Ridge meta-learner on out-of-fold predictions from base models.

    Flow:
    1. For each base model, generate OOF predictions on training data
    2. Stack OOF predictions as features for the meta-learner
    3. Train Ridge regression on these stacked features
    4. Validate on the validation set
    """
    model_names = list(models.keys())
    n_models = len(model_names)

    print(f"\n{'='*60}")
    print(f"  Training Stacking Meta-Learner (Ridge) on {n_models} base models")
    print(f"{'='*60}")

    # Generate OOF predictions for training data
    oof_train = np.zeros((len(y_train), n_models))
    oof_val = np.zeros((len(y_val), n_models))

    for i, (name, model) in enumerate(
        tqdm(models.items(), desc="  >> OOF predictions", unit="model",
             bar_format="{l_bar}{bar:30}{r_bar}")
    ):
        oof_train[:, i] = generate_oof_predictions(model, X_train, y_train)
        oof_val[:, i] = model.predict(X_val)

    # Train Ridge meta-learner on OOF predictions
    meta = Ridge(alpha=1.0)
    meta.fit(oof_train, y_train)

    # Evaluate meta-learner on validation OOF
    meta_val_pred = meta.predict(oof_val)
    val_rmse = np.sqrt(mean_squared_error(y_val, meta_val_pred))
    val_r2 = r2_score(y_val, meta_val_pred)

    print(f"\n  [OK] Meta-learner coefficients: {dict(zip(model_names, meta.coef_.round(4)))}")
    print(f"  [OK] Meta-learner Val RMSE: {val_rmse:.4f}  R2: {val_r2:.4f}")

    return meta


# ─── Main Training Pipeline ──────────────────────────────────────────────────

def train():
    """Full training pipeline with Optuna + Stacking."""
    start = time.time()
    print("\n" + "=" * 60)
    print("  AI Food Waste Reduction -- Advanced Training Pipeline")
    print("=" * 60)

    steps = [
        "Preprocessing",
        "XGBoost",
        "LightGBM",
        "CatBoost",
        "Stacking",
        "Evaluation",
        "Saving",
    ]
    pipeline_bar = tqdm(
        steps, desc="  [Pipeline]", unit="step",
        bar_format="{l_bar}{bar:30}{r_bar}",
    )

    # ── Step 1: Preprocess ────────────────────────────────────────────────
    pipeline_bar.set_description("  [1/7] Preprocessing")
    X_train, X_val, X_test, y_train, y_val, y_test, feature_cols, scaler = (
        preprocess_pipeline()
    )
    pipeline_bar.update(1)

    # ── Step 2: Tune XGBoost with Optuna ──────────────────────────────────
    pipeline_bar.set_description("  [2/7] XGBoost")
    xgb_params = tune_with_optuna(xgboost_objective, X_train, y_train, "XGBoost")
    xgb_best = build_xgboost(**xgb_params)
    xgb_best.fit(X_train, y_train)
    save_individual_model(xgb_best, "xgboost_best")

    xgb_val_pred = xgb_best.predict(X_val)
    xgb_test_pred = xgb_best.predict(X_test)
    xgb_val_metrics = compute_metrics(y_val, xgb_val_pred, "XGBoost Val")
    xgb_test_metrics = compute_metrics(y_test, xgb_test_pred, "XGBoost Test")
    pipeline_bar.update(1)

    # ── Step 3: Tune LightGBM with Optuna ─────────────────────────────────
    pipeline_bar.set_description("  [3/7] LightGBM")
    lgbm_params = tune_with_optuna(lightgbm_objective, X_train, y_train, "LightGBM")
    lgbm_best = build_lightgbm(**lgbm_params)
    lgbm_best.fit(X_train, y_train)
    save_individual_model(lgbm_best, "lightgbm_best")

    lgbm_val_pred = lgbm_best.predict(X_val)
    lgbm_test_pred = lgbm_best.predict(X_test)
    lgbm_val_metrics = compute_metrics(y_val, lgbm_val_pred, "LightGBM Val")
    lgbm_test_metrics = compute_metrics(y_test, lgbm_test_pred, "LightGBM Test")
    pipeline_bar.update(1)

    # ── Step 4: Tune CatBoost with Optuna ─────────────────────────────────
    pipeline_bar.set_description("  [4/7] CatBoost")
    cat_params = tune_with_optuna(catboost_objective, X_train, y_train, "CatBoost")
    cat_best = build_catboost(**cat_params)
    cat_best.fit(X_train, y_train)
    save_individual_model(cat_best, "catboost_best")

    cat_val_pred = cat_best.predict(X_val)
    cat_test_pred = cat_best.predict(X_test)
    cat_val_metrics = compute_metrics(y_val, cat_val_pred, "CatBoost Val")
    cat_test_metrics = compute_metrics(y_test, cat_test_pred, "CatBoost Test")
    pipeline_bar.update(1)

    # ── Step 5: Train Stacking Meta-Learner ───────────────────────────────
    pipeline_bar.set_description("  [5/7] Stacking")
    base_models = {
        "xgboost": xgb_best,
        "lightgbm": lgbm_best,
        "catboost": cat_best,
    }
    meta_learner = train_stacking_meta_learner(
        base_models, X_train, y_train, X_val, y_val
    )
    pipeline_bar.update(1)

    # ── Step 6: Final Evaluation ──────────────────────────────────────────
    pipeline_bar.set_description("  [6/7] Evaluation")

    # Build final ensemble
    ensemble = EnsembleModel(
        xgb_model=xgb_best, lgbm_model=lgbm_best, catboost_model=cat_best,
        meta_learner=meta_learner,
    )
    ensemble.save()

    ensemble_test_pred = ensemble.predict(X_test)
    ensemble_metrics = compute_metrics(y_test, ensemble_test_pred, "Stacking Ensemble Test")

    # Also compute simple weighted average for comparison
    simple_avg_pred = (xgb_test_pred + lgbm_test_pred + cat_test_pred) / 3
    simple_metrics = compute_metrics(y_test, simple_avg_pred, "Simple Average Test")

    # Print comparison table
    print(f"\n{'='*60}")
    print(f"  FINAL RESULTS COMPARISON")
    print(f"{'='*60}")
    print(f"  {'Model':<22} {'RMSE':>8} {'MAE':>8} {'R2':>8} {'MAPE':>8}")
    print(f"  {'-'*54}")
    for name, m in [
        ("XGBoost", xgb_test_metrics),
        ("LightGBM", lgbm_test_metrics),
        ("CatBoost", cat_test_metrics),
        ("Simple Average", simple_metrics),
        ("Stacking Ensemble", ensemble_metrics),
    ]:
        print(f"  {name:<22} {m['rmse']:>8.4f} {m['mae']:>8.4f} {m['r2']:>8.4f} {m['mape']:>7.2f}%")
    print(f"  {'-'*54}")
    pipeline_bar.update(1)

    # ── Step 7: Save results ──────────────────────────────────────────────
    pipeline_bar.set_description("  [7/7] Saving")
    elapsed = time.time() - start

    results = {
        "training_time_seconds": round(elapsed, 2),
        "feature_count": len(feature_cols),
        "feature_names": feature_cols,
        "tuning_method": "Optuna (TPE Bayesian optimization)",
        "n_trials_per_model": OPTUNA_N_TRIALS,
        "stacking_meta_learner": "Ridge",
        "xgboost": {
            "best_params": xgb_params,
            "val": xgb_val_metrics,
            "test": xgb_test_metrics,
        },
        "lightgbm": {
            "best_params": lgbm_params,
            "val": lgbm_val_metrics,
            "test": lgbm_test_metrics,
        },
        "catboost": {
            "best_params": cat_params,
            "val": cat_val_metrics,
            "test": cat_test_metrics,
        },
        "simple_average": {"test": simple_metrics},
        "ensemble": {"test": ensemble_metrics},
    }

    results_path = os.path.join(SAVED_MODELS_DIR, "training_results.json")
    with open(results_path, "w") as f:
        json.dump(results, f, indent=2)

    pipeline_bar.update(1)
    pipeline_bar.close()

    print(f"\n{'='*60}")
    print(f"  [DONE] Training complete in {elapsed:.1f}s ({elapsed/60:.1f} min)")
    print(f"  [BEST] Stacking Ensemble Test R2: {ensemble_metrics['r2']}")
    print(f"  [SAVE] Results -> {results_path}")
    print(f"{'='*60}\n")

    return ensemble, results


if __name__ == "__main__":
    train()
