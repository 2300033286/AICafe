"""
Model definitions for food demand prediction.
XGBoost, LightGBM, CatBoost, and a stacking ensemble.
"""
import os
import joblib
import numpy as np
from xgboost import XGBRegressor
from lightgbm import LGBMRegressor
from catboost import CatBoostRegressor
from sklearn.linear_model import Ridge
from sklearn.model_selection import KFold

from training.config import SAVED_MODELS_DIR, RANDOM_SEED, ENSEMBLE_WEIGHTS, CV_FOLDS


def build_xgboost(**kwargs) -> XGBRegressor:
    """Build an XGBoost regressor with sensible defaults."""
    defaults = dict(
        n_estimators=500,
        max_depth=6,
        learning_rate=0.05,
        subsample=0.8,
        colsample_bytree=0.8,
        min_child_weight=3,
        reg_alpha=0.1,
        reg_lambda=2.0,
        random_state=RANDOM_SEED,
        n_jobs=-1,
        verbosity=0,
    )
    defaults.update(kwargs)
    return XGBRegressor(**defaults)


def build_lightgbm(**kwargs) -> LGBMRegressor:
    """Build a LightGBM regressor with sensible defaults."""
    defaults = dict(
        n_estimators=500,
        max_depth=6,
        learning_rate=0.05,
        subsample=0.8,
        colsample_bytree=0.8,
        min_child_samples=10,
        reg_alpha=0.1,
        reg_lambda=2.0,
        num_leaves=50,
        random_state=RANDOM_SEED,
        n_jobs=-1,
        verbose=-1,
    )
    defaults.update(kwargs)
    return LGBMRegressor(**defaults)


def build_catboost(**kwargs) -> CatBoostRegressor:
    """Build a CatBoost regressor with sensible defaults."""
    defaults = dict(
        iterations=1000,
        depth=6,
        learning_rate=0.05,
        l2_leaf_reg=3.0,
        subsample=0.8,
        random_seed=RANDOM_SEED,
        verbose=0,
        allow_writing_files=False,
    )
    defaults.update(kwargs)
    return CatBoostRegressor(**defaults)


def generate_oof_predictions(model, X_train, y_train, n_splits=CV_FOLDS):
    """
    Generate out-of-fold predictions for stacking.
    Returns OOF predictions for training data.
    """
    oof_preds = np.zeros(len(y_train))
    kf = KFold(n_splits=n_splits, shuffle=True, random_state=RANDOM_SEED)

    for fold_idx, (train_idx, val_idx) in enumerate(kf.split(X_train)):
        X_tr, X_vl = X_train[train_idx], X_train[val_idx]
        y_tr = y_train[train_idx]

        # Clone the model with same params
        from sklearn.base import clone
        fold_model = clone(model)
        fold_model.fit(X_tr, y_tr)
        oof_preds[val_idx] = fold_model.predict(X_vl)

    return oof_preds


class EnsembleModel:
    """
    Stacking ensemble: XGBoost + LightGBM + CatBoost -> Ridge meta-learner.

    Level 0: Three gradient boosting models (base learners)
    Level 1: Ridge regression trained on OOF predictions from Level 0
    """

    def __init__(self, xgb_model=None, lgbm_model=None, catboost_model=None,
                 meta_learner=None, weights=None):
        self.xgb_model = xgb_model
        self.lgbm_model = lgbm_model
        self.catboost_model = catboost_model
        self.meta_learner = meta_learner
        self.weights = weights or ENSEMBLE_WEIGHTS

    def predict(self, X: np.ndarray) -> np.ndarray:
        """Make predictions using the stacking ensemble."""
        xgb_pred = self.xgb_model.predict(X)
        lgbm_pred = self.lgbm_model.predict(X)
        cat_pred = self.catboost_model.predict(X)

        if self.meta_learner is not None:
            # Stacking: use meta-learner on base predictions
            meta_features = np.column_stack([xgb_pred, lgbm_pred, cat_pred])
            combined = self.meta_learner.predict(meta_features)
        else:
            # Fallback: weighted average
            combined = (
                self.weights["xgboost"] * xgb_pred
                + self.weights["lightgbm"] * lgbm_pred
                + self.weights["catboost"] * cat_pred
            )

        # Ensure non-negative predictions (can't have negative orders)
        return np.maximum(combined, 0)

    def save(self, directory: str = SAVED_MODELS_DIR):
        os.makedirs(directory, exist_ok=True)
        joblib.dump(self.xgb_model, os.path.join(directory, "xgboost_best.joblib"))
        joblib.dump(self.lgbm_model, os.path.join(directory, "lightgbm_best.joblib"))
        joblib.dump(self.catboost_model, os.path.join(directory, "catboost_best.joblib"))
        joblib.dump(self.weights, os.path.join(directory, "ensemble_weights.joblib"))
        if self.meta_learner is not None:
            joblib.dump(self.meta_learner, os.path.join(directory, "meta_learner.joblib"))
        print(f"[Model] Stacking ensemble saved to {directory}")

    @classmethod
    def load(cls, directory: str = SAVED_MODELS_DIR) -> "EnsembleModel":
        xgb_model = joblib.load(os.path.join(directory, "xgboost_best.joblib"))
        lgbm_model = joblib.load(os.path.join(directory, "lightgbm_best.joblib"))
        catboost_model = joblib.load(os.path.join(directory, "catboost_best.joblib"))
        weights = joblib.load(os.path.join(directory, "ensemble_weights.joblib"))

        meta_path = os.path.join(directory, "meta_learner.joblib")
        meta_learner = joblib.load(meta_path) if os.path.exists(meta_path) else None

        print(f"[Model] Stacking ensemble loaded from {directory}")
        return cls(
            xgb_model=xgb_model, lgbm_model=lgbm_model,
            catboost_model=catboost_model, meta_learner=meta_learner,
            weights=weights,
        )


def save_individual_model(model, name: str, directory: str = SAVED_MODELS_DIR):
    """Save a single model."""
    os.makedirs(directory, exist_ok=True)
    path = os.path.join(directory, f"{name}.joblib")
    joblib.dump(model, path)
    print(f"[Model] Saved {name} to {path}")


def load_individual_model(name: str, directory: str = SAVED_MODELS_DIR):
    """Load a single model."""
    path = os.path.join(directory, f"{name}.joblib")
    model = joblib.load(path)
    print(f"[Model] Loaded {name} from {path}")
    return model
