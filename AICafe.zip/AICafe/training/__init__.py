# AI Food Waste Reduction - Training Pipeline
"""
Training package for food demand prediction models.
Contains data preprocessing, model definitions, training scripts,
and evaluation utilities.
"""
