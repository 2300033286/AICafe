"""
Centralized configuration for the training pipeline.
"""
import os

# ─── Paths ────────────────────────────────────────────────────────────────────
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
TRAINING_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_PATH = os.path.join(BASE_DIR, "synthetic_food_demand_train_50k.csv")
SAVED_MODELS_DIR = os.path.join(TRAINING_DIR, "saved_models")
PLOTS_DIR = os.path.join(TRAINING_DIR, "plots")
ARTIFACTS_DIR = os.path.join(TRAINING_DIR, "artifacts")  # scalers, encoders

# Create directories if they don't exist
for d in [SAVED_MODELS_DIR, PLOTS_DIR, ARTIFACTS_DIR]:
    os.makedirs(d, exist_ok=True)

# ─── Random Seed ──────────────────────────────────────────────────────────────
RANDOM_SEED = 42

# ─── Data Split ───────────────────────────────────────────────────────────────
TRAIN_RATIO = 0.70
VAL_RATIO = 0.15
TEST_RATIO = 0.15

# ─── Feature Configuration ───────────────────────────────────────────────────
TARGET_COL = "num_orders"
ID_COL = "id"

RAW_FEATURES = [
    "week", "center_id", "meal_id",
    "checkout_price", "base_price",
    "emailer_for_promotion", "homepage_featured",
]

# ─── Optuna Hyperparameter Tuning ─────────────────────────────────────────────
OPTUNA_N_TRIALS = 40         # Number of Optuna trials per model
OPTUNA_TIMEOUT = 300         # Max seconds per model optimization (safety cap)
CV_FOLDS = 5                 # Cross-validation folds
EARLY_STOPPING_ROUNDS = 50   # Early stopping patience

# ─── CatBoost Settings ───────────────────────────────────────────────────────
CATBOOST_ITERATIONS = 1000   # Max iterations (early stopping will cut short)

# ─── Ensemble ─────────────────────────────────────────────────────────────────
ENSEMBLE_WEIGHTS = {"xgboost": 0.33, "lightgbm": 0.33, "catboost": 0.34}

# ─── Outlier Handling ─────────────────────────────────────────────────────────
WINSORIZE_LOWER = 0.01       # Clip bottom 1% of target
WINSORIZE_UPPER = 0.99       # Clip top 1% of target

# ─── Target Encoding ─────────────────────────────────────────────────────────
TARGET_ENCODE_COLS = ["center_id", "meal_id"]
TARGET_ENCODE_SMOOTHING = 10  # Smoothing factor to prevent overfitting
