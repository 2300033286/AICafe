"""
Model evaluation and visualization.

Usage:
    python -m training.evaluate
"""
import os
import json
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from sklearn.metrics import (
    mean_squared_error,
    mean_absolute_error,
    r2_score,
    mean_absolute_percentage_error,
)

from training.config import SAVED_MODELS_DIR, PLOTS_DIR, ARTIFACTS_DIR
from training.data_preprocessing import preprocess_pipeline
from training.model import EnsembleModel


def plot_actual_vs_predicted(y_true, y_pred, title="Actual vs Predicted", save_path=None):
    """Scatter plot of actual vs predicted values."""
    fig, ax = plt.subplots(figsize=(8, 8))
    ax.scatter(y_true, y_pred, alpha=0.3, s=10, color="#4C72B0")
    lims = [0, max(y_true.max(), y_pred.max()) * 1.1]
    ax.plot(lims, lims, "--", color="#C44E52", linewidth=2, label="Perfect prediction")
    ax.set_xlim(lims)
    ax.set_ylim(lims)
    ax.set_xlabel("Actual Orders", fontsize=12)
    ax.set_ylabel("Predicted Orders", fontsize=12)
    ax.set_title(title, fontsize=14, fontweight="bold")
    ax.legend()
    ax.grid(True, alpha=0.3)
    plt.tight_layout()
    if save_path:
        fig.savefig(save_path, dpi=150)
        print(f"  Saved: {save_path}")
    plt.close(fig)


def plot_residuals(y_true, y_pred, title="Residual Distribution", save_path=None):
    """Histogram of prediction residuals."""
    residuals = y_true - y_pred
    fig, axes = plt.subplots(1, 2, figsize=(14, 5))

    # Histogram
    axes[0].hist(residuals, bins=50, color="#4C72B0", edgecolor="white", alpha=0.8)
    axes[0].axvline(0, color="#C44E52", linestyle="--", linewidth=2)
    axes[0].set_xlabel("Residual (Actual - Predicted)")
    axes[0].set_ylabel("Frequency")
    axes[0].set_title(f"{title} — Histogram")
    axes[0].grid(True, alpha=0.3)

    # Residual vs Predicted
    axes[1].scatter(y_pred, residuals, alpha=0.3, s=10, color="#4C72B0")
    axes[1].axhline(0, color="#C44E52", linestyle="--", linewidth=2)
    axes[1].set_xlabel("Predicted Orders")
    axes[1].set_ylabel("Residual")
    axes[1].set_title(f"{title} — vs Predicted")
    axes[1].grid(True, alpha=0.3)

    plt.tight_layout()
    if save_path:
        fig.savefig(save_path, dpi=150)
        print(f"  Saved: {save_path}")
    plt.close(fig)


def plot_feature_importance(model, feature_names, model_name="Model",
                             top_n=20, save_path=None):
    """Bar chart of top feature importances."""
    importances = model.feature_importances_
    indices = np.argsort(importances)[-top_n:]

    fig, ax = plt.subplots(figsize=(10, 8))
    ax.barh(
        range(len(indices)),
        importances[indices],
        color="#55A868",
        edgecolor="white",
    )
    ax.set_yticks(range(len(indices)))
    ax.set_yticklabels([feature_names[i] for i in indices])
    ax.set_xlabel("Importance")
    ax.set_title(f"{model_name} — Top {top_n} Feature Importances",
                 fontsize=14, fontweight="bold")
    ax.grid(True, alpha=0.3, axis="x")
    plt.tight_layout()
    if save_path:
        fig.savefig(save_path, dpi=150)
        print(f"  Saved: {save_path}")
    plt.close(fig)


def plot_error_by_center(y_true, y_pred, center_ids, save_path=None):
    """Box plot of absolute errors by center."""
    abs_errors = np.abs(y_true - y_pred)
    unique_centers = np.unique(center_ids)
    data = [abs_errors[center_ids == c] for c in unique_centers]

    fig, ax = plt.subplots(figsize=(12, 6))
    bp = ax.boxplot(data, labels=unique_centers, patch_artist=True)
    for patch in bp["boxes"]:
        patch.set_facecolor("#4C72B0")
        patch.set_alpha(0.7)
    ax.set_xlabel("Center ID", fontsize=12)
    ax.set_ylabel("Absolute Error", fontsize=12)
    ax.set_title("Prediction Error by Center", fontsize=14, fontweight="bold")
    ax.grid(True, alpha=0.3, axis="y")
    plt.tight_layout()
    if save_path:
        fig.savefig(save_path, dpi=150)
        print(f"  Saved: {save_path}")
    plt.close(fig)


def evaluate():
    """Full evaluation pipeline."""
    print("\n" + "=" * 60)
    print("  AI Food Waste Reduction — Evaluation")
    print("=" * 60)

    # Load data
    print("\n[1/4] Loading data and model...")
    X_train, X_val, X_test, y_train, y_val, y_test, feature_cols, scaler = (
        preprocess_pipeline()
    )
    ensemble = EnsembleModel.load()

    # Make predictions
    print("\n[2/4] Generating predictions...")
    y_pred = ensemble.predict(X_test)

    # Compute metrics
    print("\n[3/4] Computing metrics...")
    rmse = np.sqrt(mean_squared_error(y_test, y_pred))
    mae = mean_absolute_error(y_test, y_pred)
    r2 = r2_score(y_test, y_pred)
    mape = mean_absolute_percentage_error(y_test, y_pred) * 100

    print(f"  RMSE:  {rmse:.4f}")
    print(f"  MAE:   {mae:.4f}")
    print(f"  R²:    {r2:.4f}")
    print(f"  MAPE:  {mape:.2f}%")

    # Generate plots
    print("\n[4/4] Generating plots...")
    os.makedirs(PLOTS_DIR, exist_ok=True)

    plot_actual_vs_predicted(
        y_test, y_pred,
        title="Ensemble: Actual vs Predicted Orders",
        save_path=os.path.join(PLOTS_DIR, "actual_vs_predicted.png"),
    )
    plot_residuals(
        y_test, y_pred,
        title="Ensemble Residuals",
        save_path=os.path.join(PLOTS_DIR, "residuals.png"),
    )
    plot_feature_importance(
        ensemble.xgb_model, feature_cols,
        model_name="XGBoost",
        save_path=os.path.join(PLOTS_DIR, "xgboost_feature_importance.png"),
    )
    plot_feature_importance(
        ensemble.lgbm_model, feature_cols,
        model_name="LightGBM",
        save_path=os.path.join(PLOTS_DIR, "lightgbm_feature_importance.png"),
    )

    # Save evaluation summary
    eval_summary = {
        "rmse": round(rmse, 4),
        "mae": round(mae, 4),
        "r2": round(r2, 4),
        "mape": round(mape, 2),
        "test_samples": len(y_test),
    }
    eval_path = os.path.join(SAVED_MODELS_DIR, "evaluation_results.json")
    with open(eval_path, "w") as f:
        json.dump(eval_summary, f, indent=2)

    print(f"\n  Evaluation saved to {eval_path}")
    print(f"  Plots saved to {PLOTS_DIR}")
    print("=" * 60 + "\n")

    return eval_summary


if __name__ == "__main__":
    evaluate()
